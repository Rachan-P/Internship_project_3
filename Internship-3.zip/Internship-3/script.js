document.addEventListener('DOMContentLoaded', () => {
    let todos = JSON.parse(localStorage.getItem('todos')) || [];
    const nameInput = document.querySelector('#name');
    const newTodoForm = document.querySelector('#form');
    const statusSelect = document.querySelector('#status');
    const todoList = document.querySelector('#todo-list');

    const username = localStorage.getItem('username') || '';

    nameInput.value = username;

    nameInput.addEventListener('change', (e) => {
        localStorage.setItem('username', e.target.value);
    });

    newTodoForm.addEventListener('submit', (e) => {
        e.preventDefault();

        const todo = {
            content: e.target.elements.content.value,
            category: e.target.elements.category.value,
            done: false,
            createdAt: new Date().getTime()
        };

        todos.push(todo);

        localStorage.setItem('todos', JSON.stringify(todos));

        e.target.reset();

        displayTodos();
    });

    statusSelect.addEventListener('change', () => {
        displayTodos();
    });

    displayTodos();

    function displayTodos() {
        todoList.innerHTML = '';

        let todos = JSON.parse(localStorage.getItem('todos')) || [];
        const selectedStatus = statusSelect.value;

        todos = todos.filter((todo) => {
            if (selectedStatus === 'all') {
                return true;
            } else if (selectedStatus === 'done') {
                return todo.done;
            } else if (selectedStatus === 'pending') {
                return !todo.done;
            }
        });

        todos.forEach((todo) => {
            const todoItem = document.createElement('div');
            todoItem.classList.add('todo-item');

            const label = document.createElement('label');
            const input = document.createElement('input');
            const span = document.createElement('span');
            const content = document.createElement('div');
            const actions = document.createElement('div');
            const editIcon = document.createElement('i');
            const deleteIcon = document.createElement('i');

            input.type = 'checkbox';
            input.checked = todo.done;
            span.classList.add('bubble');
            if (todo.category === 'personal') {
                span.classList.add('personal');
            } else {
                span.classList.add('business');
            }
            content.classList.add('todo-content');
            actions.classList.add('actions');
            editIcon.classList.add('fa', 'fa-pencil-alt', 'edit-icon');
            deleteIcon.classList.add('fa', 'fa-trash', 'delete-icon');

            content.innerHTML = `<input type="text" style="width:90%;" value="${todo.content}" readonly>`;

            label.appendChild(input);
            label.appendChild(span);
            actions.appendChild(editIcon);
            actions.appendChild(deleteIcon);
            todoItem.appendChild(label);
            todoItem.appendChild(content);
            todoItem.appendChild(actions);

            if (todo.done) {
                todoItem.classList.add('done');
            }

            input.addEventListener('change', (e) => {
                todo.done = e.target.checked;
                localStorage.setItem('todos', JSON.stringify(todos));
                displayTodos();
            });

            editIcon.addEventListener('click', (e) => {
                const inputField = content.querySelector('input');
                if (inputField.hasAttribute('readonly')) {
                    inputField.removeAttribute('readonly');
                    inputField.focus();
                } else {
                    inputField.setAttribute('readonly', true);
                    todo.content = inputField.value;
                    localStorage.setItem('todos', JSON.stringify(todos));
                    displayTodos();
                }
            });

            deleteIcon.addEventListener('click', (e) => {
                // Smooth fade-out animation and removal
                fadeOutAndRemove(todoItem);

                todos = todos.filter((t) => t !== todo);
                localStorage.setItem('todos', JSON.stringify(todos));
            });

            editIcon.addEventListener('click', (e) => {
                const inputField = content.querySelector('input');
                if (inputField.hasAttribute('readonly')) {
                    inputField.removeAttribute('readonly');
                    setTimeout(() => {
                        inputField.focus();
                        // Set the cursor to the end of the input text
                        inputField.setSelectionRange(inputField.value.length, inputField.value.length);
                    }, 0);
                } else {
                    // Add an event listener for the Enter key press to save the changes
                    inputField.addEventListener('keyup', (e) => {
                        if (e.key === 'Enter') {
                            inputField.setAttribute('readonly', true);
                            todo.content = inputField.value;
                            localStorage.setItem('todos', JSON.stringify(todos));
                            displayTodos();
                        }
                    });
                }
            });
            

            todoList.appendChild(todoItem);
        });
    }

    // Function to add the fade-out class and remove the element after animation
    function fadeOutAndRemove(element) {
        element.classList.add('fade-out');
        element.addEventListener('transitionend', () => {
            element.remove();
        });
    }
});

